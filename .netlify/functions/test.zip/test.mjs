
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/test.mjs
async function handler(request, context) {
  const url = new URL(request.url);
  return new Response(JSON.stringify({
    ok: true,
    method: request.method,
    url: request.url,
    pathname: url.pathname,
    search: url.search,
    isRequest: request instanceof Request
  }, null, 2), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
}
export {
  handler as default
};
